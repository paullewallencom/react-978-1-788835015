import React from 'react';
import MyList from './MyList';

const App = () => <MyList />;

export default App;
