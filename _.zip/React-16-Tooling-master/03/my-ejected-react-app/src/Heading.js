import React from 'react';

const Heading = ({ children }) => (
  <h1>{children}</h1>
);

export default Heading;
