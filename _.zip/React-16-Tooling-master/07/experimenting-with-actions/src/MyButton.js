import React from 'react';

const MyButton = ({ onClick }) => (
  <button onClick={onClick}>My Button</button>
);

export default MyButton;
