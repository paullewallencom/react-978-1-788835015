module.exports = {
  "extends": "react-app"
};
