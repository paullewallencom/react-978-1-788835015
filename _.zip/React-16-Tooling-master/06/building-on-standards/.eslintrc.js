module.exports = {
  "extends": "airbnb-base",
  "rules": {
    "no-console": 0
  }
};
