describe('NestedSuite', () => {
  describe('state', () => {
    it('handles the first state', () => {

    });

    it('handles the second state', () => {

    });
  });

  describe('props', () => {
    it('handles the first prop', () => {

    });

    it('handles the second prop', () => {

    });
  });

  describe('render()', () => {
    it('renders with state', () => {

    });

    it('renders with props', () => {

    });
  });
});
